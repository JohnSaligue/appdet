<?php
include 'config.php';
requireRole('admin');

if (isset($_POST['delete_id'])) {
    run("DELETE FROM applications WHERE application_id=?", 'i', array((int)$_POST['delete_id']));
    flash('success', 'Application deleted.');
    redirect('applications.php');
}

$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';
$scholarship = $_GET['scholarship'] ?? '';
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$where = array('1=1'); $types = ''; $params = array();
if ($q != '') { $where[] = '(s.name LIKE ? OR s.student_id LIKE ?)'; $types .= 'ss'; $params[] = "%$q%"; $params[] = "%$q%"; }
if ($status != '') { $where[] = 'a.status_id=?'; $types .= 'i'; $params[] = (int)$status; }
if ($scholarship != '') { $where[] = 'a.scholarship_id=?'; $types .= 'i'; $params[] = (int)$scholarship; }
if ($from != '' && validDate($from)) { $where[] = 'a.application_date >= ?'; $types .= 's'; $params[] = $from; }
if ($to != '' && validDate($to)) { $where[] = 'a.application_date <= ?'; $types .= 's'; $params[] = $to; }
list($sort, $dir, $col) = getSort(array('date' => 'a.application_date', 'student' => 's.name',
    'scholarship' => 'sc.name', 'gpa' => 'a.gpa', 'status' => 'a.status_id'), 'date');
if (!isset($_GET['sort'])) $dir = 'DESC';

$rows = fetchAll("SELECT a.*, s.name AS student_name, sc.name AS scholarship_name, sc.min_gpa, sc.deadline, st.status_name
                  FROM applications a
                  JOIN students s ON a.student_id=s.student_id
                  JOIN scholarships sc ON a.scholarship_id=sc.scholarship_id
                  JOIN statuses st ON a.status_id=st.status_id
                  WHERE " . implode(' AND ', $where) . " ORDER BY $col $dir", $types, $params);
$statuses = fetchAll("SELECT * FROM statuses ORDER BY status_id");
$scholarships = fetchAll("SELECT scholarship_id, name FROM scholarships ORDER BY name");

$pageTitle = 'Applications';
include 'header.php';
?>
<h1 class="page-title">Applications</h1>
<?php
$tabCounts = array();
foreach (fetchAll("SELECT status_id, COUNT(*) AS n FROM applications GROUP BY status_id") as $t) $tabCounts[$t['status_id']] = $t['n'];
?>
<div class="status-tabs no-print">
  <a class="<?php echo $status == '' ? 'on' : ''; ?>" href="applications.php">All <span><?php echo array_sum($tabCounts); ?></span></a>
  <?php foreach ($statuses as $s) { ?>
    <a class="<?php echo $status == $s['status_id'] ? 'on' : ''; ?>" href="applications.php?status=<?php echo $s['status_id']; ?>">
      <?php echo h($s['status_name']); ?> <span><?php echo $tabCounts[$s['status_id']] ?? 0; ?></span></a>
  <?php } ?>
</div>
<form method="get" class="filter-bar row g-2 mb-3">
  <div class="col-md-3"><input type="text" name="q" class="form-control" placeholder="Search student name / ID" value="<?php echo h($q); ?>"></div>
  <div class="col-md-2">
    <select name="status" class="form-select">
      <option value="">All statuses</option>
      <?php foreach ($statuses as $s) { ?>
        <option value="<?php echo $s['status_id']; ?>" <?php if ($status == $s['status_id']) echo 'selected'; ?>><?php echo h($s['status_name']); ?></option>
      <?php } ?>
    </select>
  </div>
  <div class="col-md-3">
    <select name="scholarship" class="form-select">
      <option value="">All scholarships</option>
      <?php foreach ($scholarships as $s) { ?>
        <option value="<?php echo $s['scholarship_id']; ?>" <?php if ($scholarship == $s['scholarship_id']) echo 'selected'; ?>><?php echo h($s['name']); ?></option>
      <?php } ?>
    </select>
  </div>
  <div class="col-md-2"><input type="date" name="from" class="form-control" title="Applied from" value="<?php echo h($from); ?>"></div>
  <div class="col-md-2"><input type="date" name="to" class="form-control" title="Applied to" value="<?php echo h($to); ?>"></div>
  <div class="col-12">
    <button class="btn btn-primary">Search</button>
    <a href="applications.php" class="btn btn-outline-secondary">Reset</a>
  </div>
</form>

<div class="table-responsive">
<table class="table table-striped table-hover align-middle">
  <thead><tr>
    <th><?php echo sortLink('date', 'Date', $sort, $dir); ?></th>
    <th><?php echo sortLink('student', 'Student', $sort, $dir); ?></th>
    <th><?php echo sortLink('scholarship', 'Scholarship', $sort, $dir); ?></th>
    <th><?php echo sortLink('gpa', 'GPA', $sort, $dir); ?></th>
    <th>Eligibility</th>
    <th><?php echo sortLink('status', 'Status', $sort, $dir); ?></th>
    <th>Actions</th>
  </tr></thead>
  <tbody>
  <?php foreach ($rows as $r) {
      $problems = eligibilityProblems($r['gpa'], $r['application_date'], $r['min_gpa'], $r['deadline']); ?>
    <tr>
      <td><?php echo h($r['application_date']); ?></td>
      <td><?php echo h($r['student_name']); ?><br><small class="text-muted"><?php echo h($r['student_id']); ?></small></td>
      <td><?php echo h($r['scholarship_name']); ?></td>
      <td><?php echo h($r['gpa']); ?></td>
      <td><?php echo count($problems) == 0 ? '<span class="badge bg-success">Eligible</span>' : '<span class="badge bg-danger">Not eligible</span>'; ?></td>
      <td><?php echo badge($r['status_name']); ?></td>
      <td class="text-nowrap">
        <a class="btn btn-sm btn-primary" href="evaluate.php?id=<?php echo $r['application_id']; ?>"><i class="bi bi-clipboard-check"></i> Review</a>
        <form method="post" class="d-inline" onsubmit="return confirm('Delete this application?');">
          <input type="hidden" name="delete_id" value="<?php echo $r['application_id']; ?>">
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i> Delete</button>
        </form>
      </td>
    </tr>
  <?php }
  if (count($rows) == 0) echo '<tr><td colspan="7" class="text-center">No applications found.</td></tr>'; ?>
  </tbody>
</table>
</div>
<p class="text-muted"><?php echo count($rows); ?> record(s)</p>
<?php include 'footer.php'; ?>
