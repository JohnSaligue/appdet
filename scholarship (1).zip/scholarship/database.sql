-- Scholarship Management System  |  import this file in phpMyAdmin (Import tab)
CREATE DATABASE IF NOT EXISTS db_scholarship;
USE db_scholarship;

DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS scholarships;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS statuses;
DROP TABLE IF EXISTS providers;
DROP TABLE IF EXISTS programs;

CREATE TABLE programs (
  program_id   INT AUTO_INCREMENT PRIMARY KEY,
  program_name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE providers (
  provider_id   INT AUTO_INCREMENT PRIMARY KEY,
  provider_name VARCHAR(100) NOT NULL UNIQUE,
  contact_info  VARCHAR(100) NULL
) ENGINE=InnoDB;

CREATE TABLE statuses (
  status_id   INT PRIMARY KEY,
  status_name VARCHAR(20) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE students (
  student_id VARCHAR(20)  PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  program_id INT          NOT NULL,
  year_level TINYINT      NOT NULL,
  gpa        DECIMAL(3,2) NOT NULL,
  contact    VARCHAR(100) NOT NULL,
  FOREIGN KEY (program_id) REFERENCES programs(program_id)
) ENGINE=InnoDB;

CREATE TABLE users (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','student') NOT NULL,
  student_id    VARCHAR(20)  NULL UNIQUE,
  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE scholarships (
  scholarship_id INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(100) NOT NULL UNIQUE,
  provider_id    INT          NOT NULL,
  min_gpa        DECIMAL(3,2) NOT NULL,
  requirements   TEXT         NULL,
  slots          INT          NOT NULL,
  deadline       DATE         NOT NULL,
  FOREIGN KEY (provider_id) REFERENCES providers(provider_id)
) ENGINE=InnoDB;

CREATE TABLE applications (
  application_id   INT AUTO_INCREMENT PRIMARY KEY,
  student_id       VARCHAR(20) NOT NULL,
  scholarship_id   INT         NOT NULL,
  application_date DATE        NOT NULL,
  gpa              DECIMAL(3,2) NOT NULL,
  status_id        INT         NOT NULL DEFAULT 1,
  remarks          TEXT        NULL,
  UNIQUE KEY one_application (student_id, scholarship_id),
  FOREIGN KEY (student_id)     REFERENCES students(student_id),
  FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id),
  FOREIGN KEY (status_id)      REFERENCES statuses(status_id)
) ENGINE=InnoDB;

-- ---------- sample records ----------
INSERT INTO statuses VALUES (1,'Pending'),(2,'Under Review'),(3,'Approved'),(4,'Rejected');

INSERT INTO programs (program_name) VALUES
 ('BS Information Technology'),('BS Computer Science'),('BS Business Administration'),
 ('BS Education'),('BS Nursing');

INSERT INTO providers (provider_name, contact_info) VALUES
 ('Office of Student Affairs','osa@university.edu'),
 ('Commission on Higher Education (CHED)','ched@example.gov'),
 ('Rotary Club','rotary@example.org'),
 ('Alumni Association','alumni@university.edu');

INSERT INTO students VALUES
 ('2024-0001','Juan Dela Cruz',1,3,3.65,'juan@example.com'),
 ('2024-0002','Maria Santos',2,2,3.90,'maria@example.com'),
 ('2024-0003','Pedro Reyes',3,4,2.80,'pedro@example.com'),
 ('2024-0004','Ana Garcia',4,1,3.20,'ana@example.com'),
 ('2024-0005','Jose Ramos',5,3,2.45,'jose@example.com'),
 ('2024-0006','Liza Mendoza',1,2,3.55,'liza@example.com'),
 ('2024-0007','Carlo Bautista',2,4,3.10,'carlo@example.com'),
 ('2024-0008','Rina Aquino',3,1,3.75,'rina@example.com');

INSERT INTO scholarships (name, provider_id, min_gpa, requirements, slots, deadline) VALUES
 ('Academic Excellence Award',1,3.50,'Transcript of records, recommendation letter',3,'2026-12-15'),
 ('CHED Merit Scholarship',2,3.00,'Certificate of enrollment, income certificate',5,'2026-11-30'),
 ('Rotary Community Leaders Grant',3,2.75,'Essay and proof of community service',2,'2026-09-30'),
 ('Alumni Support Grant',4,2.50,'Letter of intent, barangay certificate',4,'2027-01-31');

INSERT INTO applications (student_id, scholarship_id, application_date, gpa, status_id, remarks) VALUES
 ('2024-0001',1,'2026-10-02',3.65,3,'Complete requirements. Approved.'),
 ('2024-0002',1,'2026-10-03',3.90,3,'Outstanding academic record.'),
 ('2024-0006',1,'2026-10-05',3.55,2,'Verifying documents.'),
 ('2024-0003',1,'2026-10-06',2.80,4,'GPA below the minimum requirement.'),
 ('2024-0004',2,'2026-10-07',3.20,1,NULL),
 ('2024-0007',2,'2026-10-08',3.10,2,'Waiting for income certificate.'),
 ('2024-0008',2,'2026-10-10',3.75,3,'Approved.'),
 ('2024-0003',3,'2026-09-15',2.80,3,'Active in community service.'),
 ('2024-0005',4,'2026-10-12',2.45,4,'GPA below the minimum requirement.'),
 ('2024-0004',4,'2026-10-14',3.20,1,NULL);

-- Login accounts (admin / student1 / student2) are created automatically with
-- hashed passwords the first time any page is opened. See README.txt.
