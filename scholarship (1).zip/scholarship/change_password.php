<?php
include 'config.php';
requireRole('any');
$errors = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $u = fetchOne("SELECT * FROM users WHERE user_id=?", 'i', array($_SESSION['user_id']));
    if (!password_verify($_POST['old'], $u['password_hash'])) $errors[] = 'Old password is wrong.';
    if (strlen($_POST['new']) < 6) $errors[] = 'New password must be at least 6 characters.';
    if ($_POST['new'] != $_POST['confirm']) $errors[] = 'New passwords do not match.';
    if (count($errors) == 0) {
        run("UPDATE users SET password_hash=? WHERE user_id=?", 'si',
            array(password_hash($_POST['new'], PASSWORD_DEFAULT), $_SESSION['user_id']));
        flash('success', 'Password changed.');
        redirect('index.php');
    }
}
$pageTitle = 'Change Password';
include 'header.php';
?>
<div class="row justify-content-center"><div class="col-md-5">
  <h1 class="page-title">Change Password</h1>
  <?php foreach ($errors as $e) echo '<div class="alert alert-danger">' . h($e) . '</div>'; ?>
  <div class="card stat-card"><div class="card-body">
    <form method="post">
      <div class="mb-3"><label class="form-label">Old password</label><input type="password" name="old" class="form-control"></div>
      <div class="mb-3"><label class="form-label">New password</label><input type="password" name="new" class="form-control"></div>
      <div class="mb-3"><label class="form-label">Confirm new password</label><input type="password" name="confirm" class="form-control"></div>
      <button class="btn btn-primary w-100">Change Password</button>
    </form>
  </div></div>
</div></div>
<?php include 'footer.php'; ?>
