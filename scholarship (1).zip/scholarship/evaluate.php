<?php
include 'config.php';
requireRole('admin');

$id = (int)($_GET['id'] ?? 0);
$app = fetchOne("SELECT a.*, s.name AS student_name, s.year_level, s.contact, p.program_name,
                 sc.name AS scholarship_name, sc.min_gpa, sc.slots, sc.deadline, sc.requirements, pr.provider_name
                 FROM applications a
                 JOIN students s ON a.student_id=s.student_id
                 JOIN programs p ON s.program_id=p.program_id
                 JOIN scholarships sc ON a.scholarship_id=sc.scholarship_id
                 JOIN providers pr ON sc.provider_id=pr.provider_id
                 WHERE a.application_id=?", 'i', array($id));
if ($app == null) { flash('danger', 'Application not found.'); redirect('applications.php'); }

$approvedCount = countOf("SELECT COUNT(*) FROM applications WHERE scholarship_id=? AND status_id=3", 'i', array($app['scholarship_id']));
$slotsLeft = $app['slots'] - $approvedCount;
$statuses = fetchAll("SELECT * FROM statuses ORDER BY status_id");
$errors = array();
$newStatus = $app['status_id'];
$remarks = $app['remarks'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newStatus = (int)$_POST['status_id'];
    $remarks = trim($_POST['remarks']);

    if (fetchOne("SELECT status_id FROM statuses WHERE status_id=?", 'i', array($newStatus)) == null)
        $errors[] = 'Please choose a valid status.';
    if ($newStatus == ST_REJECTED && $remarks == '')
        $errors[] = 'Please add remarks explaining why the application is rejected.';
    if ($newStatus == ST_APPROVED && $app['status_id'] != ST_APPROVED && $slotsLeft <= 0)
        $errors[] = 'Cannot approve: no slots left for this scholarship.';

    if (count($errors) == 0) {
        run("UPDATE applications SET status_id=?, remarks=? WHERE application_id=?", 'isi', array($newStatus, $remarks, $id));
        flash('success', 'Application updated.');
        redirect('applications.php');
    }
}
$problems = eligibilityProblems($app['gpa'], $app['application_date'], $app['min_gpa'], $app['deadline'],
                                $app['status_id'] == ST_APPROVED ? null : $slotsLeft);
$pageTitle = 'Evaluate';
include 'header.php';
?>
<h1 class="page-title">Evaluate Application #<?php echo $id; ?></h1>
<?php if (count($errors) > 0) { ?>
  <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>' . h($e) . '</li>'; ?></ul></div>
<?php } ?>
<div class="row g-3">
  <div class="col-md-6"><div class="card stat-card h-100"><div class="card-body">
    <h5 class="text-primary">Student</h5>
    <p class="mb-1"><b><?php echo h($app['student_name']); ?></b> (<?php echo h($app['student_id']); ?>)</p>
    <p class="mb-1"><?php echo h($app['program_name']); ?>, Year <?php echo h($app['year_level']); ?></p>
    <p class="mb-1">Contact: <?php echo h($app['contact']); ?></p>
    <p class="mb-0">GPA at application: <b><?php echo h($app['gpa']); ?></b></p>
  </div></div></div>
  <div class="col-md-6"><div class="card stat-card h-100"><div class="card-body">
    <h5 class="text-primary">Scholarship</h5>
    <p class="mb-1"><b><?php echo h($app['scholarship_name']); ?></b> - <?php echo h($app['provider_name']); ?></p>
    <p class="mb-1">Minimum GPA: <?php echo h($app['min_gpa']); ?> &middot; Deadline: <?php echo h($app['deadline']); ?></p>
    <p class="mb-1">Slots left: <?php echo $slotsLeft; ?> of <?php echo $app['slots']; ?></p>
    <p class="mb-0">Requirements: <?php echo h($app['requirements']); ?></p>
  </div></div></div>

  <div class="col-12"><div class="card stat-card"><div class="card-body">
    <h5 class="text-primary">Eligibility check</h5>
    <p class="mb-1">Applied on <?php echo h($app['application_date']); ?></p>
    <?php if (count($problems) == 0) { ?>
      <span class="badge bg-success fs-6">Eligible</span> GPA meets the minimum, applied before the deadline<?php echo $app['status_id'] == ST_APPROVED ? '' : ', slots available'; ?>.
    <?php } else { ?>
      <span class="badge bg-danger fs-6">Not eligible</span>
      <ul class="mb-0 mt-2"><?php foreach ($problems as $p) echo '<li>' . h($p) . '</li>'; ?></ul>
    <?php } ?>
  </div></div></div>

  <div class="col-12"><div class="card stat-card"><div class="card-body">
    <h5 class="text-primary">Decision</h5>
    <form method="post" class="row g-3">
      <div class="col-12">
        <label class="form-label d-block">Set status</label>
        <div class="status-radio">
          <?php foreach ($statuses as $s) { ?>
            <input type="radio" class="btn-check" name="status_id" id="st<?php echo $s['status_id']; ?>"
                   value="<?php echo $s['status_id']; ?>" <?php if ($newStatus == $s['status_id']) echo 'checked'; ?>>
            <label class="btn" for="st<?php echo $s['status_id']; ?>"><?php echo h($s['status_name']); ?></label>
          <?php } ?>
        </div>
      </div>
      <div class="col-12">
        <label class="form-label">Evaluation remarks</label>
        <textarea name="remarks" rows="3" class="form-control"><?php echo h($remarks); ?></textarea>
      </div>
      <div class="col-12">
        <button class="btn btn-primary px-4">Save</button>
        <a href="applications.php" class="btn btn-outline-secondary">Back</a>
      </div>
    </form>
  </div></div></div>
</div>
<?php include 'footer.php'; ?>
