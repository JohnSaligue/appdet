<?php
include 'config.php';
requireRole('admin');

$editing = isset($_GET['id']) && $_GET['id'] != '';
$programs = fetchAll("SELECT * FROM programs ORDER BY program_name");
$errors = array();
$d = array('student_id' => '', 'name' => '', 'program_id' => '', 'year_level' => '1', 'gpa' => '', 'contact' => '');

if ($editing) {
    $row = fetchOne("SELECT * FROM students WHERE student_id=?", 's', array($_GET['id']));
    if ($row == null) { flash('danger', 'Student not found.'); redirect('students.php'); }
    $d = $row;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($d as $k => $v) $d[$k] = trim($_POST[$k] ?? '');
    if ($editing) $d['student_id'] = $_GET['id'];      // ID cannot be changed

    foreach (array('student_id' => 'Student ID', 'name' => 'Name', 'program_id' => 'Program',
                   'gpa' => 'GPA', 'contact' => 'Contact information') as $k => $label) {
        if ($d[$k] == '') $errors[] = "$label is required.";
    }
    if ($d['student_id'] != '' && !preg_match('/^[A-Za-z0-9-]{3,20}$/', $d['student_id']))
        $errors[] = 'Student ID may only contain letters, numbers and dashes (3-20 characters).';
    if ($d['gpa'] != '' && (!is_numeric($d['gpa']) || $d['gpa'] < 0 || $d['gpa'] > 4))
        $errors[] = 'GPA must be a number from 0.00 to 4.00.';
    if (!in_array($d['year_level'], array('1', '2', '3', '4'))) $errors[] = 'Year level must be 1 to 4.';
    if ($d['program_id'] != '' && fetchOne("SELECT program_id FROM programs WHERE program_id=?", 'i', array((int)$d['program_id'])) == null)
        $errors[] = 'Please choose a valid program.';
    if (!$editing && count($errors) == 0 &&
        fetchOne("SELECT student_id FROM students WHERE student_id=?", 's', array($d['student_id'])) != null)
        $errors[] = 'That Student ID already exists.';

    if (count($errors) == 0) {
        if ($editing) {
            run("UPDATE students SET name=?, program_id=?, year_level=?, gpa=?, contact=? WHERE student_id=?",
                'siidss', array($d['name'], (int)$d['program_id'], (int)$d['year_level'], (float)$d['gpa'], $d['contact'], $d['student_id']));
            flash('success', 'Student updated.');
        } else {
            run("INSERT INTO students (student_id, name, program_id, year_level, gpa, contact) VALUES (?,?,?,?,?,?)",
                'ssiids', array($d['student_id'], $d['name'], (int)$d['program_id'], (int)$d['year_level'], (float)$d['gpa'], $d['contact']));
            flash('success', 'Student added.');
        }
        redirect('students.php');
    }
}
$pageTitle = $editing ? 'Edit Student' : 'Add Student';
include 'header.php';
?>
<div class="row justify-content-center"><div class="col-lg-7">
  <h1 class="page-title"><?php echo $pageTitle; ?></h1>
  <?php if (count($errors) > 0) { ?>
    <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>' . h($e) . '</li>'; ?></ul></div>
  <?php } ?>
  <div class="card stat-card"><div class="card-body">
    <form method="post" class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Student ID *</label>
        <input type="text" name="student_id" class="form-control" value="<?php echo h($d['student_id']); ?>" <?php if ($editing) echo 'readonly'; ?>>
      </div>
      <div class="col-md-6">
        <label class="form-label">Full name *</label>
        <input type="text" name="name" class="form-control" value="<?php echo h($d['name']); ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Program *</label>
        <select name="program_id" class="form-select">
          <option value="">-- choose --</option>
          <?php foreach ($programs as $p) { ?>
            <option value="<?php echo $p['program_id']; ?>" <?php if ($d['program_id'] == $p['program_id']) echo 'selected'; ?>><?php echo h($p['program_name']); ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label">Year level *</label>
        <select name="year_level" class="form-select">
          <?php for ($i = 1; $i <= 4; $i++) { ?><option <?php if ($d['year_level'] == $i) echo 'selected'; ?>><?php echo $i; ?></option><?php } ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label">GPA (0.00 - 4.00) *</label>
        <input type="number" step="0.01" min="0" max="4" name="gpa" class="form-control" value="<?php echo h($d['gpa']); ?>">
      </div>
      <div class="col-12">
        <label class="form-label">Contact information *</label>
        <input type="text" name="contact" class="form-control" value="<?php echo h($d['contact']); ?>">
      </div>
      <div class="col-12 text-center">
        <button class="btn btn-primary px-4">Save</button>
        <a href="students.php" class="btn btn-outline-secondary">Cancel</a>
      </div>
    </form>
  </div></div>
</div></div>
<?php include 'footer.php'; ?>
