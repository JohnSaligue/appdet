<?php
include 'config.php';
requireRole('student');

$sid = $_SESSION['student_id'];
$sch = fetchOne("SELECT sc.*, pr.provider_name,
                 (SELECT COUNT(*) FROM applications a WHERE a.scholarship_id=sc.scholarship_id AND a.status_id=3) AS approved_count
                 FROM scholarships sc JOIN providers pr ON sc.provider_id=pr.provider_id
                 WHERE sc.scholarship_id=?", 'i', array((int)($_GET['id'] ?? 0)));
if ($sch == null) { flash('danger', 'Scholarship not found.'); redirect('scholarships.php'); }
$me = fetchOne("SELECT * FROM students WHERE student_id=?", 's', array($sid));
$errors = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (fetchOne("SELECT application_id FROM applications WHERE student_id=? AND scholarship_id=?", 'si', array($sid, $sch['scholarship_id'])) != null)
        $errors[] = 'You already applied for this scholarship.';
    if (date('Y-m-d') > $sch['deadline']) $errors[] = 'The deadline for this scholarship has passed.';

    if (count($errors) == 0) {
        run("INSERT INTO applications (student_id, scholarship_id, application_date, gpa, status_id) VALUES (?,?,?,?,1)",
            'sisd', array($sid, $sch['scholarship_id'], date('Y-m-d'), (float)$me['gpa']));
        flash('success', 'Application submitted. Status: Pending.');
        redirect('my_applications.php');
    }
}
$problems = eligibilityProblems($me['gpa'], date('Y-m-d'), $sch['min_gpa'], $sch['deadline'], $sch['slots'] - $sch['approved_count']);
$pageTitle = 'Apply';
include 'header.php';
?>
<div class="row justify-content-center"><div class="col-lg-7">
  <h1 class="page-title">Apply for Scholarship</h1>
  <?php foreach ($errors as $e) echo '<div class="alert alert-danger">' . h($e) . '</div>'; ?>
  <div class="card stat-card"><div class="card-body">
    <h4 class="text-primary"><?php echo h($sch['name']); ?></h4>
    <p class="mb-1"><b>Provider:</b> <?php echo h($sch['provider_name']); ?></p>
    <p class="mb-1"><b>Minimum GPA:</b> <?php echo h($sch['min_gpa']); ?></p>
    <p class="mb-1"><b>Slots left:</b> <?php echo $sch['slots'] - $sch['approved_count']; ?> of <?php echo $sch['slots']; ?></p>
    <p class="mb-1"><b>Deadline:</b> <?php echo h($sch['deadline']); ?></p>
    <p><b>Requirements:</b> <?php echo h($sch['requirements']); ?></p>
    <hr>
    <p><b>Your GPA:</b> <?php echo h($me['gpa']); ?></p>
    <?php if (count($problems) > 0) { ?>
      <div class="alert alert-warning">Heads up: <?php echo h(implode('; ', $problems)); ?>. You may still submit, but the administrator will check your eligibility.</div>
    <?php } else { ?>
      <div class="alert alert-success">You appear to meet the requirements.</div>
    <?php } ?>
    <form method="post" class="text-center">
      <button class="btn btn-primary px-4">Submit Application</button>
      <a href="scholarships.php" class="btn btn-outline-secondary">Cancel</a>
    </form>
  </div></div>
</div></div>
<?php include 'footer.php'; ?>
