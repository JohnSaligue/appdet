    </div>
    <div class="page-foot no-print">ScholarTrack &middot; Scholarship Management System</div>
  </main>
<?php if (isset($_SESSION['user_id'])) echo '</div>'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
