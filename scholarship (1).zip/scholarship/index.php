<?php
include 'config.php';
$pageTitle = 'Home';

function kpi($icon, $n, $label, $tone) {
    return '<div class="col-6 col-md-4 col-xl-2"><div class="kpi kpi-' . $tone . '">' .
           '<span class="kpi-icon"><i class="bi bi-' . $icon . '"></i></span>' .
           '<div class="kpi-num">' . $n . '</div><div class="kpi-label">' . h($label) . '</div></div></div>';
}

include 'header.php';

if (!isset($_SESSION['user_id'])) {
    // ================= public landing page =================
    $open = fetchAll("SELECT sc.*, pr.provider_name,
                      (SELECT COUNT(*) FROM applications a WHERE a.scholarship_id=sc.scholarship_id AND a.status_id=3) AS approved_count
                      FROM scholarships sc JOIN providers pr ON sc.provider_id=pr.provider_id
                      WHERE sc.deadline >= CURDATE() ORDER BY sc.deadline");
    $slotsOpen = 0; foreach ($open as $o) $slotsOpen += max(0, $o['slots'] - $o['approved_count']);
?>
<section class="land-hero">
  <div class="land-text">
    <span class="tag"><i class="bi bi-broadcast"></i> Enrollment is now open</span>
    <h1>Find a scholarship.<br><em>Apply in minutes.</em></h1>
    <p>Create your student account, pick a scholarship that fits your GPA, and follow your
       application from Pending to Approved &mdash; all in one place.</p>
    <div class="d-flex flex-wrap gap-2">
      <a href="register.php" class="btn btn-primary btn-lg">Create my account <i class="bi bi-arrow-right"></i></a>
      <a href="login.php" class="btn btn-outline-secondary btn-lg">I already have one</a>
    </div>
    <div class="land-stats">
      <div><b><?php echo count($open); ?></b><span>open scholarships</span></div>
      <div><b><?php echo $slotsOpen; ?></b><span>slots available</span></div>
      <div><b><?php echo count($open) > 0 ? h($open[0]['deadline']) : '-'; ?></b><span>next deadline</span></div>
    </div>
  </div>
  <div class="land-art" aria-hidden="true">
    <div class="art-card a1"><i class="bi bi-person-check"></i><div><b>Account created</b><small>Takes about a minute</small></div></div>
    <div class="art-card a2"><i class="bi bi-send-check"></i><div><b>Application sent</b><small>Status: Pending</small></div></div>
    <div class="art-card a3"><i class="bi bi-patch-check-fill"></i><div><b>Approved!</b><small>Congratulations</small></div></div>
  </div>
</section>

<h2 class="section-title">How it works</h2>
<div class="steps">
  <div class="step"><span>1</span><h6>Enroll</h6><p>Create your student account with your ID, program and GPA.</p></div>
  <div class="step"><span>2</span><h6>Choose &amp; apply</h6><p>Browse open scholarships and apply with one click.</p></div>
  <div class="step"><span>3</span><h6>Track</h6><p>Watch your status and read the evaluator's remarks.</p></div>
</div>

<h2 class="section-title">Open scholarships</h2>
<div class="sch-grid">
  <?php foreach ($open as $s) echo scholarCard($s, '<a href="register.php" class="btn btn-primary w-100">Enroll to apply</a>'); ?>
</div>
<?php if (count($open) == 0) echo '<p class="text-muted">Scholarships will be posted soon.</p>'; ?>

<?php } elseif (isAdmin()) {
    // ================= admin overview =================
    $counts = array(); foreach (fetchAll("SELECT status_id, COUNT(*) n FROM applications GROUP BY status_id") as $c) $counts[$c['status_id']] = $c['n'];
    $total = array_sum($counts);
    $pending = ($counts[1] ?? 0) + ($counts[2] ?? 0);
    $recent = fetchAll("SELECT a.*, s.name AS student_name, sc.name AS scholarship_name, st.status_name
                        FROM applications a
                        JOIN students s ON a.student_id=s.student_id
                        JOIN scholarships sc ON a.scholarship_id=sc.scholarship_id
                        JOIN statuses st ON a.status_id=st.status_id
                        ORDER BY a.application_id DESC LIMIT 5");
?>
<div class="page-head"><h1 class="page-title">Overview</h1></div>

<div class="row g-3 mb-4">
  <?php echo kpi('people', countOf("SELECT COUNT(*) FROM students"), 'Students', 'teal');
        echo kpi('award', countOf("SELECT COUNT(*) FROM scholarships"), 'Scholarships', 'sun');
        echo kpi('inboxes', $total, 'Applications', 'sky');
        echo kpi('hourglass-split', $pending, 'Waiting', 'sun');
        echo kpi('check2-circle', $counts[3] ?? 0, 'Approved', 'green');
        echo kpi('x-circle', $counts[4] ?? 0, 'Rejected', 'rose'); ?>
</div>

<div class="row g-3 mb-4">
  <div class="col-lg-7">
    <div class="panel h-100">
      <h6 class="panel-title">Application status</h6>
      <?php if ($total > 0) { ?>
      <div class="stack-bar">
        <?php foreach (array(1 => 'pending', 2 => 'review', 3 => 'approved', 4 => 'rejected') as $id => $cls) {
            $n = $counts[$id] ?? 0; if ($n == 0) continue; ?>
          <div class="seg seg-<?php echo $cls; ?>" style="width:<?php echo round($n / $total * 100, 1); ?>%" title="<?php echo $n; ?>"><?php echo $n; ?></div>
        <?php } ?>
      </div>
      <div class="legend">
        <span><i class="dot seg-pending"></i> Pending</span><span><i class="dot seg-review"></i> Under review</span>
        <span><i class="dot seg-approved"></i> Approved</span><span><i class="dot seg-rejected"></i> Rejected</span>
      </div>
      <?php } else { echo '<p class="text-muted mb-0">No applications yet.</p>'; } ?>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="panel h-100 todo">
      <h6 class="panel-title"><span class="title-icon"><i class="bi bi-bell"></i></span> Needs your attention</h6>
      <div class="todo-num"><?php echo $counts[1] ?? 0; ?></div>
      <div class="mb-3">application(s) still <b>Pending</b></div>
      <a href="applications.php?status=1" class="btn btn-primary"><i class="bi bi-clipboard-check"></i> Start reviewing <i class="bi bi-chevron-right"></i></a>
      <div class="todo-art" aria-hidden="true"><i class="bi bi-bell"></i><i class="bi bi-book"></i></div>
    </div>
  </div>
</div>

<h2 class="section-title">Quick actions</h2>
<div class="tiles mb-4">
  <a class="tile" href="student_form.php"><i class="bi bi-person-plus"></i><b>Add student</b><small>Create a record</small></a>
  <a class="tile" href="scholarship_form.php"><i class="bi bi-plus-square"></i><b>New scholarship</b><small>Post an opportunity</small></a>
  <a class="tile" href="applications.php"><i class="bi bi-inboxes"></i><b>All applications</b><small>Search &amp; filter</small></a>
  <a class="tile" href="reports.php?type=detailed"><i class="bi bi-printer"></i><b>Print a report</b><small>Summary or detailed</small></a>
</div>

<h2 class="section-title">Recent applications</h2>
<div class="table-responsive"><table class="table align-middle">
  <thead><tr><th>Date</th><th>Student</th><th>Scholarship</th><th>GPA</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($recent as $r) { ?>
    <tr><td><?php echo h($r['application_date']); ?></td><td><?php echo h($r['student_name']); ?></td>
        <td><?php echo h($r['scholarship_name']); ?></td><td><?php echo h($r['gpa']); ?></td>
        <td><?php echo badge($r['status_name']); ?></td>
        <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="evaluate.php?id=<?php echo $r['application_id']; ?>"><i class="bi bi-clipboard-check"></i> Review</a></td></tr>
  <?php }
  if (count($recent) == 0) echo '<tr><td colspan="6" class="text-center text-muted">No applications yet.</td></tr>'; ?>
  </tbody>
</table></div>

<?php } else {
    // ================= student home =================
    $sid = $_SESSION['student_id'];
    $me = fetchOne("SELECT s.*, p.program_name FROM students s JOIN programs p ON s.program_id=p.program_id WHERE s.student_id=?", 's', array($sid));
    $mine = countOf("SELECT COUNT(*) FROM applications WHERE student_id=?", 's', array($sid));
    $approved = countOf("SELECT COUNT(*) FROM applications WHERE student_id=? AND status_id=3", 's', array($sid));
    $waiting = countOf("SELECT COUNT(*) FROM applications WHERE student_id=? AND status_id IN (1,2)", 's', array($sid));
    $openCount = countOf("SELECT COUNT(*) FROM scholarships WHERE deadline >= CURDATE()");
    $recent = fetchAll("SELECT a.*, sc.name AS scholarship_name, st.status_name FROM applications a
                        JOIN scholarships sc ON a.scholarship_id=sc.scholarship_id
                        JOIN statuses st ON a.status_id=st.status_id
                        WHERE a.student_id=? ORDER BY a.application_id DESC LIMIT 5", 's', array($sid));
?>
<div class="profile-banner">
  <span class="avatar big"><?php echo strtoupper(substr($me['name'], 0, 1)); ?></span>
  <div>
    <h1><?php echo h($me['name']); ?></h1>
    <p><?php echo h($me['program_name']); ?> &middot; Year <?php echo h($me['year_level']); ?> &middot; ID <?php echo h($me['student_id']); ?></p>
  </div>
  <div class="gpa-badge"><small>Your GPA</small><b><?php echo h($me['gpa']); ?></b></div>
</div>

<div class="row g-3 mb-4">
  <?php echo kpi('inboxes', $mine, 'Applications', 'sky');
        echo kpi('hourglass-split', $waiting, 'Waiting', 'sun');
        echo kpi('check2-circle', $approved, 'Approved', 'green');
        echo kpi('compass', $openCount, 'Open to apply', 'teal'); ?>
</div>

<div class="tiles mb-4">
  <a class="tile" href="scholarships.php"><i class="bi bi-compass"></i><b>Find scholarships</b><small>See what you qualify for</small></a>
  <a class="tile" href="my_applications.php"><i class="bi bi-clipboard2-check"></i><b>My applications</b><small>Track your status</small></a>
</div>

<h2 class="section-title">Latest activity</h2>
<div class="table-responsive"><table class="table align-middle">
  <thead><tr><th>Date</th><th>Scholarship</th><th>Status</th><th>Remarks</th></tr></thead>
  <tbody>
  <?php foreach ($recent as $r) { ?>
    <tr><td><?php echo h($r['application_date']); ?></td><td><?php echo h($r['scholarship_name']); ?></td>
        <td><?php echo badge($r['status_name']); ?></td><td><?php echo h($r['remarks']); ?></td></tr>
  <?php }
  if (count($recent) == 0) echo '<tr><td colspan="4" class="text-center text-muted">You have not applied yet. Try "Find scholarships".</td></tr>'; ?>
  </tbody>
</table></div>
<?php } ?>
<?php include 'footer.php'; ?>
