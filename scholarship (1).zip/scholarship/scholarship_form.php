<?php
include 'config.php';
requireRole('admin');

$editing = isset($_GET['id']) && $_GET['id'] != '';
$id = $editing ? (int)$_GET['id'] : 0;
$providers = fetchAll("SELECT * FROM providers ORDER BY provider_name");
$errors = array();
$d = array('name' => '', 'provider_id' => '', 'min_gpa' => '', 'requirements' => '', 'slots' => '', 'deadline' => '');

if ($editing) {
    $row = fetchOne("SELECT * FROM scholarships WHERE scholarship_id=?", 'i', array($id));
    if ($row == null) { flash('danger', 'Scholarship not found.'); redirect('scholarships.php'); }
    $d = $row;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($d as $k => $v) $d[$k] = trim($_POST[$k] ?? '');

    foreach (array('name' => 'Scholarship name', 'provider_id' => 'Provider', 'min_gpa' => 'Minimum GPA',
                   'slots' => 'Number of slots', 'deadline' => 'Application deadline') as $k => $label) {
        if ($d[$k] == '') $errors[] = "$label is required.";
    }
    if (strlen($d['name']) > 100) $errors[] = 'Scholarship name is too long (max 100 characters).';
    if ($d['provider_id'] != '' && fetchOne("SELECT provider_id FROM providers WHERE provider_id=?", 'i', array((int)$d['provider_id'])) == null)
        $errors[] = 'Please choose a valid provider.';
    if ($d['min_gpa'] != '' && (!is_numeric($d['min_gpa']) || $d['min_gpa'] < 0 || $d['min_gpa'] > 4))
        $errors[] = 'Minimum GPA must be a number from 0.00 to 4.00.';
    if ($d['slots'] != '' && (!ctype_digit($d['slots']) || (int)$d['slots'] < 1))
        $errors[] = 'Number of slots must be a whole number of at least 1.';
    if ($d['deadline'] != '' && !validDate($d['deadline'])) $errors[] = 'Deadline is not a valid date.';
    if ($d['name'] != '' && fetchOne("SELECT scholarship_id FROM scholarships WHERE name=? AND scholarship_id<>?", 'si', array($d['name'], $id)) != null)
        $errors[] = 'A scholarship with that name already exists.';
    if ($editing && $d['slots'] != '' && ctype_digit($d['slots'])) {
        $approved = countOf("SELECT COUNT(*) FROM applications WHERE scholarship_id=? AND status_id=3", 'i', array($id));
        if ((int)$d['slots'] < $approved) $errors[] = "Slots cannot be lower than the $approved already approved applicant(s).";
    }

    if (count($errors) == 0) {
        if ($editing) {
            run("UPDATE scholarships SET name=?, provider_id=?, min_gpa=?, requirements=?, slots=?, deadline=? WHERE scholarship_id=?",
                'sidsisi', array($d['name'], (int)$d['provider_id'], (float)$d['min_gpa'], $d['requirements'], (int)$d['slots'], $d['deadline'], $id));
            flash('success', 'Scholarship updated.');
        } else {
            run("INSERT INTO scholarships (name, provider_id, min_gpa, requirements, slots, deadline) VALUES (?,?,?,?,?,?)",
                'sidsis', array($d['name'], (int)$d['provider_id'], (float)$d['min_gpa'], $d['requirements'], (int)$d['slots'], $d['deadline']));
            flash('success', 'Scholarship added.');
        }
        redirect('scholarships.php');
    }
}
$pageTitle = $editing ? 'Edit Scholarship' : 'Add Scholarship';
include 'header.php';
?>
<div class="row justify-content-center"><div class="col-lg-7">
  <h1 class="page-title"><?php echo $pageTitle; ?></h1>
  <?php if (count($errors) > 0) { ?>
    <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>' . h($e) . '</li>'; ?></ul></div>
  <?php } ?>
  <div class="card stat-card"><div class="card-body">
    <form method="post" class="row g-3">
      <div class="col-md-7">
        <label class="form-label">Scholarship name *</label>
        <input type="text" name="name" class="form-control" value="<?php echo h($d['name']); ?>">
      </div>
      <div class="col-md-5">
        <label class="form-label">Provider *</label>
        <select name="provider_id" class="form-select">
          <option value="">-- choose --</option>
          <?php foreach ($providers as $p) { ?>
            <option value="<?php echo $p['provider_id']; ?>" <?php if ($d['provider_id'] == $p['provider_id']) echo 'selected'; ?>><?php echo h($p['provider_name']); ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Minimum GPA *</label>
        <input type="number" step="0.01" min="0" max="4" name="min_gpa" class="form-control" value="<?php echo h($d['min_gpa']); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Number of slots *</label>
        <input type="number" min="1" name="slots" class="form-control" value="<?php echo h($d['slots']); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Application deadline *</label>
        <input type="date" name="deadline" class="form-control" value="<?php echo h($d['deadline']); ?>">
      </div>
      <div class="col-12">
        <label class="form-label">Requirements</label>
        <textarea name="requirements" rows="3" class="form-control"><?php echo h($d['requirements']); ?></textarea>
      </div>
      <div class="col-12 text-center">
        <button class="btn btn-primary px-4">Save</button>
        <a href="scholarships.php" class="btn btn-outline-secondary">Cancel</a>
      </div>
    </form>
  </div></div>
</div></div>
<?php include 'footer.php'; ?>
