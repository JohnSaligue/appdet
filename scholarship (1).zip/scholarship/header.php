<?php
if (!isset($pageTitle)) $pageTitle = 'ScholarTrack';
$cur = basename($_SERVER['PHP_SELF']);
$loggedIn = isset($_SESSION['user_id']);

$fullName = '';
if ($loggedIn) {
    if (isAdmin()) {
        $fullName = ucfirst($_SESSION['username']);
    } else {
        $row = fetchOne("SELECT name FROM students WHERE student_id=?", 's', array($_SESSION['student_id']));
        $fullName = $row ? $row['name'] : $_SESSION['username'];
    }
}

// one sidebar link; the first file name is where it goes, the others just keep it highlighted
function navItem($files, $icon, $label) {
    global $cur;
    $files = (array)$files;
    $active = in_array($cur, $files) ? ' active' : '';
    echo '<a class="side-link' . $active . '" href="' . $files[0] . '"><i class="bi bi-' . $icon . '"></i><span>' . $label . '</span></a>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo h($pageTitle); ?> | ScholarTrack</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="assets/custom.css" rel="stylesheet">
</head>
<body>
<div class="bg-deco no-print" aria-hidden="true">
  <span class="blob blob-tr"></span><span class="blob blob-br"></span>
  <i class="bi bi-pen deco-tr"></i><i class="bi bi-journal-bookmark deco-br"></i>
</div>
<?php if ($loggedIn) { ?>
<div class="shell">
  <aside class="sidebar offcanvas-lg offcanvas-start no-print" tabindex="-1" id="sidebar">
    <div class="offcanvas-header">
      <span></span>
      <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebar"></button>
    </div>
    <div class="offcanvas-body">
      <a class="brand" href="index.php"><i class="bi bi-mortarboard-fill"></i><span>Scholar <b>Track</b></span></a>

      <?php if (isAdmin()) { ?>
        <div class="side-label">Main</div>
        <?php navItem('index.php', 'grid-1x2', 'Overview');
              navItem(array('applications.php', 'evaluate.php'), 'inboxes', 'Applications');
              navItem(array('students.php', 'student_form.php'), 'people', 'Students');
              navItem(array('scholarships.php', 'scholarship_form.php'), 'award', 'Scholarships');
              navItem('reports.php', 'bar-chart-line', 'Reports'); ?>
        <div class="side-label">Setup</div>
        <?php navItem('programs.php', 'journal-bookmark', 'Programs');
              navItem('providers.php', 'building', 'Providers'); ?>
      <?php } else { ?>
        <div class="side-label">Menu</div>
        <?php navItem('index.php', 'house-heart', 'Home');
              navItem(array('scholarships.php', 'apply.php'), 'compass', 'Find scholarships');
              navItem('my_applications.php', 'clipboard2-check', 'My applications'); ?>
      <?php } ?>

      <div class="side-bottom">
        <?php navItem('change_password.php', 'key', 'Change password'); ?>
        <a class="side-link" href="logout.php"><i class="bi bi-box-arrow-left"></i><span>Log out</span></a>
      </div>
      <div class="side-art" aria-hidden="true">
        <svg viewBox="0 0 260 150" preserveAspectRatio="none">
          <path d="M0 62 C60 14 130 104 260 34 L260 150 L0 150 Z" fill="#FFCCE0"/>
          <path d="M0 108 C70 72 150 138 260 92 L260 150 L0 150 Z" fill="#2F64A0" opacity=".6"/>
        </svg>
        <i class="bi bi-book deco-book"></i><i class="bi bi-pen deco-pen"></i>
      </div>
    </div>
  </aside>

  <main class="main-area">
    <div class="topbar no-print">
      <button class="btn btn-icon d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#sidebar"><i class="bi bi-list"></i></button>
      <div class="greet">
        <?php $hr = (int)date('G'); echo $hr < 12 ? 'Good morning' : ($hr < 18 ? 'Good afternoon' : 'Good evening'); ?>,
        <b><?php echo h($fullName); ?></b>
      </div>
      <div class="user-chip">
        <span class="avatar"><?php echo strtoupper(substr($fullName, 0, 1)); ?></span>
        <span class="d-none d-sm-inline"><?php echo h($fullName); ?></span>
      </div>
    </div>
    <div class="content">
<?php } else { ?>
  <header class="guest-bar no-print">
    <a class="brand" href="index.php"><i class="bi bi-mortarboard-fill"></i><span>Scholar <b>Track</b></span></a>
    <div>
      <a class="btn btn-ghost" href="login.php">Log in</a>
      <a class="btn btn-primary" href="register.php">Enroll now</a>
    </div>
  </header>
  <main class="guest-area">
    <div class="content">
<?php } ?>
<?php
if (isset($_SESSION['flash'])) {
    $icon = $_SESSION['flash']['type'] == 'success' ? 'check-circle-fill' : 'exclamation-triangle-fill';
    echo '<div class="alert alert-' . h($_SESSION['flash']['type']) . ' alert-dismissible fade show no-print">' .
         '<i class="bi bi-' . $icon . ' me-2"></i>' . h($_SESSION['flash']['msg']) .
         '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    unset($_SESSION['flash']);
}
?>
