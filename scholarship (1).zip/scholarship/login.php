<?php
include 'config.php';
if (isset($_SESSION['user_id'])) redirect('index.php');
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if ($username == '' || $password == '') {
        $error = 'Please enter your username and password.';
    } else {
        $u = fetchOne("SELECT * FROM users WHERE username=?", 's', array($username));
        if ($u != null && password_verify($password, $u['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $u['user_id'];
            $_SESSION['username'] = $u['username'];
            $_SESSION['role'] = $u['role'];
            $_SESSION['student_id'] = $u['student_id'];
            redirect('index.php');
        }
        $error = 'Wrong username or password.';
    }
}
$pageTitle = 'Log in';
include 'header.php';
?>
<div class="auth-split">
  <div class="auth-side">
    <i class="bi bi-mortarboard-fill big-icon"></i>
    <h2>Welcome back</h2>
    <p>Log in to apply for scholarships and see how your applications are doing.</p>
    <ul>
      <li><i class="bi bi-check2-circle"></i> One account for every scholarship</li>
      <li><i class="bi bi-check2-circle"></i> Live application status</li>
      <li><i class="bi bi-check2-circle"></i> Read the evaluator's remarks</li>
    </ul>
  </div>
  <div class="auth-form">
    <h3>Log in</h3>
    <?php if ($error != '') { ?><div class="alert alert-danger"><?php echo h($error); ?></div><?php } ?>
    <form method="post">
      <label class="form-label">Username</label>
      <div class="input-icon mb-3"><i class="bi bi-person"></i>
        <input type="text" name="username" class="form-control" value="<?php echo h($_POST['username'] ?? ''); ?>" autofocus></div>
      <label class="form-label">Password</label>
      <div class="input-icon mb-4"><i class="bi bi-lock"></i>
        <input type="password" name="password" class="form-control"></div>
      <button class="btn btn-primary w-100 btn-lg">Log in</button>
    </form>
    <p class="text-center mt-3 mb-0">New here? <a href="register.php">Create a student account</a></p>
  </div>
</div>
<?php include 'footer.php'; ?>
