<?php
// ---------- Connection, session and helper functions used by every page ----------
session_start();
date_default_timezone_set('Asia/Manila');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);   // errors become exceptions

$conn = mysqli_connect('localhost', 'root', '', 'db_scholarship');   // XAMPP defaults
mysqli_set_charset($conn, 'utf8mb4');

// status ids (see statuses table)
define('ST_PENDING', 1);
define('ST_REVIEW', 2);
define('ST_APPROVED', 3);
define('ST_REJECTED', 4);

// ---------- database helpers (prepared statements) ----------
function fetchAll($sql, $types = '', $params = array()) {
    global $conn;
    $stmt = mysqli_prepare($conn, $sql);
    if ($types != '') mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function fetchOne($sql, $types = '', $params = array()) {
    $rows = fetchAll($sql, $types, $params);
    return count($rows) > 0 ? $rows[0] : null;
}

function run($sql, $types = '', $params = array()) {      // INSERT / UPDATE / DELETE
    global $conn;
    $stmt = mysqli_prepare($conn, $sql);
    if ($types != '') mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_affected_rows($stmt);
}

function countOf($sql, $types = '', $params = array()) {
    $row = fetchOne($sql, $types, $params);
    return (int)array_values($row)[0];
}

// ---------- general helpers ----------
function h($text) { return htmlspecialchars((string)$text); }

function redirect($url) { header("Location: $url"); exit; }

function flash($type, $msg) { $_SESSION['flash'] = array('type' => $type, 'msg' => $msg); }

function isAdmin() { return isset($_SESSION['role']) && $_SESSION['role'] == 'admin'; }

function requireRole($role) {            // 'admin', 'student' or 'any'
    if (!isset($_SESSION['user_id'])) redirect('login.php');
    if ($role != 'any' && $_SESSION['role'] != $role) redirect('index.php');
}

function validDate($d) {
    $dt = DateTime::createFromFormat('Y-m-d', $d);
    return $dt && $dt->format('Y-m-d') == $d;
}

function badge($status) {
    $classes = array('Pending' => 'pill-pending', 'Under Review' => 'pill-review',
                     'Approved' => 'pill-approved', 'Rejected' => 'pill-rejected');
    $c = isset($classes[$status]) ? $classes[$status] : 'pill-pending';
    return '<span class="status-pill ' . $c . '">' . h($status) . '</span>';
}

function daysLeft($deadline) {
    return (int)((strtotime($deadline) - strtotime(date('Y-m-d'))) / 86400);
}

// One scholarship card (used on the landing page and the student scholarship list).
// $s needs: name, provider_name, min_gpa, slots, approved_count, requirements, deadline
function scholarCard($s, $actionHtml) {
    $left = $s['slots'] - $s['approved_count'];
    $days = daysLeft($s['deadline']);
    $pct = $s['slots'] > 0 ? round($s['approved_count'] / $s['slots'] * 100) : 0;
    if ($days < 0) { $when = 'Closed'; $cls = 'late'; }
    elseif ($days == 0) { $when = 'Last day!'; $cls = 'soon'; }
    elseif ($days <= 7) { $when = $days . ' day' . ($days > 1 ? 's' : '') . ' left'; $cls = 'soon'; }
    else { $when = $days . ' days left'; $cls = ''; }
    $html  = '<div class="sch-card">';
    $html .= '<div class="sch-top"><span class="sch-provider">' . h($s['provider_name']) . '</span>';
    $html .= '<span class="sch-when ' . $cls . '"><i class="bi bi-clock"></i> ' . $when . '</span></div>';
    $html .= '<h5>' . h($s['name']) . '</h5>';
    $html .= '<p class="sch-req">' . h($s['requirements']) . '</p>';
    $html .= '<div class="sch-chips"><span><i class="bi bi-mortarboard"></i> GPA ' . h($s['min_gpa']) . '+</span>';
    $html .= '<span><i class="bi bi-calendar-event"></i> ' . h($s['deadline']) . '</span></div>';
    $html .= '<div class="sch-slots"><div class="bar"><div style="width:' . $pct . '%"></div></div>';
    $html .= '<small>' . $left . ' of ' . $s['slots'] . ' slots left</small></div>';
    $html .= '<div class="sch-action">' . $actionHtml . '</div></div>';
    return $html;
}

// Eligibility check. Returns a list of problems (empty list = eligible).
function eligibilityProblems($gpa, $appDate, $minGpa, $deadline, $slotsLeft = null) {
    $p = array();
    if ((float)$gpa < (float)$minGpa)
        $p[] = 'GPA (' . number_format($gpa, 2) . ') is below the minimum (' . number_format($minGpa, 2) . ')';
    if ($appDate > $deadline) $p[] = 'Applied after the deadline';
    if ($slotsLeft !== null && $slotsLeft <= 0) $p[] = 'No slots left';
    return $p;
}

// ---------- sorting helpers for list pages ----------
function getSort($map, $default) {
    $key = isset($_GET['sort']) ? $_GET['sort'] : $default;
    if (!isset($map[$key])) $key = $default;
    $dir = (isset($_GET['dir']) && $_GET['dir'] == 'DESC') ? 'DESC' : 'ASC';
    return array($key, $dir, $map[$key]);
}

function sortLink($col, $label, $sort, $dir) {
    $newDir = ($sort == $col && $dir == 'ASC') ? 'DESC' : 'ASC';
    $params = $_GET;
    $params['sort'] = $col;
    $params['dir'] = $newDir;
    $arrow = ($sort == $col) ? ($dir == 'ASC' ? ' &#9650;' : ' &#9660;') : '';
    return '<a class="sort-link" href="?' . h(http_build_query($params)) . '">' . $label . $arrow . '</a>';
}

// ---------- first run: create the default login accounts ----------
// (password_hash cannot be written in the .sql file, so PHP creates the accounts)
if (countOf("SELECT COUNT(*) FROM users WHERE role='admin'") == 0) {
    run("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
        'ss', array('admin', password_hash('admin123', PASSWORD_DEFAULT)));
    $demo = array(array('student1', '2024-0001'), array('student2', '2024-0002'));
    foreach ($demo as $d) {
        if (fetchOne("SELECT student_id FROM students WHERE student_id=?", 's', array($d[1])) != null) {
            run("INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, 'student', ?)",
                'sss', array($d[0], password_hash('student123', PASSWORD_DEFAULT), $d[1]));
        }
    }
}
?>
