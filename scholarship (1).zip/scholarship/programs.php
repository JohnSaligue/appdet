<?php
include 'config.php';
requireRole('admin');
$errors = array();
$editId = (int)($_GET['edit'] ?? 0);
$name = '';

if (isset($_POST['delete_id'])) {
    try {
        run("DELETE FROM programs WHERE program_id=?", 'i', array((int)$_POST['delete_id']));
        flash('success', 'Program deleted.');
    } catch (mysqli_sql_exception $e) {
        flash('danger', 'Cannot delete this program because students are enrolled in it.');
    }
    redirect('programs.php');
}

if (isset($_POST['save'])) {
    $editId = (int)$_POST['program_id'];
    $name = trim($_POST['program_name']);
    if ($name == '') $errors[] = 'Program name is required.';
    elseif (strlen($name) > 100) $errors[] = 'Program name is too long (max 100 characters).';
    elseif (fetchOne("SELECT program_id FROM programs WHERE program_name=? AND program_id<>?", 'si', array($name, $editId)) != null)
        $errors[] = 'That program already exists.';

    if (count($errors) == 0) {
        if ($editId > 0) run("UPDATE programs SET program_name=? WHERE program_id=?", 'si', array($name, $editId));
        else run("INSERT INTO programs (program_name) VALUES (?)", 's', array($name));
        flash('success', 'Program saved.');
        redirect('programs.php');
    }
} elseif ($editId > 0) {
    $row = fetchOne("SELECT * FROM programs WHERE program_id=?", 'i', array($editId));
    if ($row != null) $name = $row['program_name']; else $editId = 0;
}

$rows = fetchAll("SELECT p.*, (SELECT COUNT(*) FROM students s WHERE s.program_id=p.program_id) AS total
                  FROM programs p ORDER BY p.program_name");
$pageTitle = 'Programs';
include 'header.php';
?>
<h1 class="page-title">Programs</h1>
<?php foreach ($errors as $e) echo '<div class="alert alert-danger">' . h($e) . '</div>'; ?>
<form method="post" class="filter-bar row g-2 mb-4">
  <input type="hidden" name="program_id" value="<?php echo $editId; ?>">
  <div class="col-md-6"><input type="text" name="program_name" class="form-control" placeholder="Program name *" value="<?php echo h($name); ?>"></div>
  <div class="col-md-6">
    <button name="save" class="btn btn-primary"><?php echo $editId > 0 ? 'Update' : 'Add'; ?> Program</button>
    <?php if ($editId > 0) echo '<a href="programs.php" class="btn btn-outline-secondary">Cancel</a>'; ?>
  </div>
</form>
<div class="table-responsive"><table class="table table-striped align-middle">
  <thead><tr><th>Program</th><th>Students</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r) { ?>
    <tr><td><?php echo h($r['program_name']); ?></td><td><?php echo $r['total']; ?></td>
      <td class="text-nowrap">
        <a class="btn btn-sm btn-outline-primary" href="programs.php?edit=<?php echo $r['program_id']; ?>"><i class="bi bi-pencil-square"></i> Edit</a>
        <form method="post" class="d-inline" onsubmit="return confirm('Delete this program?');">
          <input type="hidden" name="delete_id" value="<?php echo $r['program_id']; ?>">
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i> Delete</button>
        </form>
      </td></tr>
  <?php } ?>
  </tbody>
</table></div>
<?php include 'footer.php'; ?>
