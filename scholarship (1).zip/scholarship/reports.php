<?php
include 'config.php';
requireRole('admin');

$type = (($_GET['type'] ?? 'summary') == 'detailed') ? 'detailed' : 'summary';
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';
$status = $_GET['status'] ?? '';
$scholarship = $_GET['scholarship'] ?? '';
$fromSql = ($from != '' && validDate($from)) ? $from : '1000-01-01';   // no date = no limit
$toSql = ($to != '' && validDate($to)) ? $to : '9999-12-31';
$periodText = ($from != '' || $to != '') ? (($from != '' ? $from : 'beginning') . ' to ' . ($to != '' ? $to : 'today')) : 'All dates';

// ---------- detailed report data ----------
if ($type == 'detailed') {
    $where = array('a.application_date BETWEEN ? AND ?'); $types = 'ss'; $params = array($fromSql, $toSql);
    if ($status != '') { $where[] = 'a.status_id=?'; $types .= 'i'; $params[] = (int)$status; }
    if ($scholarship != '') { $where[] = 'a.scholarship_id=?'; $types .= 'i'; $params[] = (int)$scholarship; }
    list($sort, $dir, $col) = getSort(array('date' => 'a.application_date', 'student' => 's.name',
        'scholarship' => 'sc.name', 'gpa' => 'a.gpa', 'status' => 'a.status_id'), 'scholarship');
    $detail = fetchAll("SELECT a.*, s.name AS student_name, p.program_name, sc.name AS scholarship_name, st.status_name
                        FROM applications a
                        JOIN students s ON a.student_id=s.student_id
                        JOIN programs p ON s.program_id=p.program_id
                        JOIN scholarships sc ON a.scholarship_id=sc.scholarship_id
                        JOIN statuses st ON a.status_id=st.status_id
                        WHERE " . implode(' AND ', $where) . " ORDER BY $col $dir, s.name", $types, $params);

    // CSV export (opens in Excel)
    if (($_GET['export'] ?? '') == 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="applications_report.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, array('Date', 'Student ID', 'Student', 'Program', 'Scholarship', 'GPA', 'Status', 'Remarks'));
        foreach ($detail as $r)
            fputcsv($out, array($r['application_date'], $r['student_id'], $r['student_name'], $r['program_name'],
                                $r['scholarship_name'], $r['gpa'], $r['status_name'], $r['remarks']));
        fclose($out);
        exit;
    }
    $statuses = fetchAll("SELECT * FROM statuses ORDER BY status_id");
    $scholarships = fetchAll("SELECT scholarship_id, name FROM scholarships ORDER BY name");
}

// ---------- summary report data ----------
if ($type == 'summary') {
    $statusCounts = fetchAll("SELECT st.status_name, COUNT(a.application_id) AS n
                              FROM statuses st
                              LEFT JOIN applications a ON a.status_id=st.status_id AND a.application_date BETWEEN ? AND ?
                              GROUP BY st.status_id, st.status_name ORDER BY st.status_id", 'ss', array($fromSql, $toSql));
    $perScholarship = fetchAll("SELECT sc.name,
                                COUNT(a.application_id) AS total,
                                COUNT(CASE WHEN a.status_id=1 THEN 1 END) AS pending,
                                COUNT(CASE WHEN a.status_id=2 THEN 1 END) AS review,
                                COUNT(CASE WHEN a.status_id=3 THEN 1 END) AS approved,
                                COUNT(CASE WHEN a.status_id=4 THEN 1 END) AS rejected
                                FROM scholarships sc
                                LEFT JOIN applications a ON a.scholarship_id=sc.scholarship_id AND a.application_date BETWEEN ? AND ?
                                GROUP BY sc.scholarship_id, sc.name ORDER BY sc.name", 'ss', array($fromSql, $toSql));
    $availability = fetchAll("SELECT sc.name, sc.slots, sc.deadline,
                              (SELECT COUNT(*) FROM applications a WHERE a.scholarship_id=sc.scholarship_id AND a.status_id=3) AS approved
                              FROM scholarships sc ORDER BY sc.name");
    $gpaStats = array(
        'All students'        => fetchOne("SELECT COUNT(*) n, AVG(gpa) a, MAX(gpa) mx, MIN(gpa) mn FROM students"),
        'Applicants'          => fetchOne("SELECT COUNT(*) n, AVG(gpa) a, MAX(gpa) mx, MIN(gpa) mn FROM applications WHERE application_date BETWEEN ? AND ?", 'ss', array($fromSql, $toSql)),
        'Approved applicants' => fetchOne("SELECT COUNT(*) n, AVG(gpa) a, MAX(gpa) mx, MIN(gpa) mn FROM applications WHERE status_id=3 AND application_date BETWEEN ? AND ?", 'ss', array($fromSql, $toSql)),
    );
}

$pageTitle = 'Reports';
include 'header.php';
$tabQuery = http_build_query(array('from' => $from, 'to' => $to));
?>
<h1 class="page-title no-print">Reports</h1>

<ul class="nav nav-tabs mb-3 no-print">
  <li class="nav-item"><a class="nav-link <?php echo $type == 'summary' ? 'active' : ''; ?>" href="reports.php?type=summary&<?php echo h($tabQuery); ?>">Summary Report</a></li>
  <li class="nav-item"><a class="nav-link <?php echo $type == 'detailed' ? 'active' : ''; ?>" href="reports.php?type=detailed&<?php echo h($tabQuery); ?>">Detailed Report</a></li>
</ul>

<form method="get" class="filter-bar row g-2 mb-3 no-print">
  <input type="hidden" name="type" value="<?php echo $type; ?>">
  <div class="col-md-2"><label class="form-label mb-0 small">Applied from</label><input type="date" name="from" class="form-control" value="<?php echo h($from); ?>"></div>
  <div class="col-md-2"><label class="form-label mb-0 small">Applied to</label><input type="date" name="to" class="form-control" value="<?php echo h($to); ?>"></div>
  <?php if ($type == 'detailed') { ?>
  <div class="col-md-3"><label class="form-label mb-0 small">Status</label>
    <select name="status" class="form-select"><option value="">All statuses</option>
      <?php foreach ($statuses as $s) { ?><option value="<?php echo $s['status_id']; ?>" <?php if ($status == $s['status_id']) echo 'selected'; ?>><?php echo h($s['status_name']); ?></option><?php } ?>
    </select></div>
  <div class="col-md-3"><label class="form-label mb-0 small">Scholarship</label>
    <select name="scholarship" class="form-select"><option value="">All scholarships</option>
      <?php foreach ($scholarships as $s) { ?><option value="<?php echo $s['scholarship_id']; ?>" <?php if ($scholarship == $s['scholarship_id']) echo 'selected'; ?>><?php echo h($s['name']); ?></option><?php } ?>
    </select></div>
  <?php } ?>
  <div class="col-md-2 d-flex align-items-end">
    <button class="btn btn-primary me-1">Filter</button>
    <a href="reports.php?type=<?php echo $type; ?>" class="btn btn-outline-secondary">Reset</a>
  </div>
</form>

<div class="mb-3 no-print">
  <button onclick="window.print()" class="btn btn-warning">Print Report</button>
  <?php if ($type == 'detailed') {
      $csv = $_GET; $csv['export'] = 'csv'; $csv['type'] = 'detailed'; ?>
    <a href="reports.php?<?php echo h(http_build_query($csv)); ?>" class="btn btn-success">Export to Excel (CSV)</a>
    <a href="reports.php?type=detailed&status=3&<?php echo h($tabQuery); ?>" class="btn btn-outline-primary">Approved applicants</a>
    <a href="reports.php?type=detailed&status=4&<?php echo h($tabQuery); ?>" class="btn btn-outline-primary">Rejected applicants</a>
  <?php } ?>
</div>

<div class="print-only text-center mb-3">
  <h3>Scholarship Management System</h3>
</div>
<h4 class="text-primary"><?php echo $type == 'summary' ? 'Summary Report' : 'Detailed Report'; ?></h4>
<p class="text-muted">Application date: <?php echo h($periodText); ?> &middot; Generated <?php echo date('Y-m-d H:i'); ?></p>

<?php if ($type == 'summary') { ?>

<div class="row g-3 mb-4">
  <?php $total = 0; foreach ($statusCounts as $s) $total += $s['n']; ?>
  <div class="col-6 col-md"><div class="card stat-card text-center"><div class="card-body"><div class="number"><?php echo $total; ?></div>Total applications</div></div></div>
  <?php foreach ($statusCounts as $s) { ?>
  <div class="col-6 col-md"><div class="card stat-card text-center"><div class="card-body"><div class="number"><?php echo $s['n']; ?></div><?php echo h($s['status_name']); ?></div></div></div>
  <?php } ?>
</div>

<h5>Applicants per Scholarship</h5>
<div class="table-responsive"><table class="table table-striped table-sm align-middle">
  <thead><tr><th>Scholarship</th><th>Total</th><th>Pending</th><th>Under Review</th><th>Approved</th><th>Rejected</th></tr></thead>
  <tbody>
  <?php foreach ($perScholarship as $r) { ?>
    <tr><td><?php echo h($r['name']); ?></td><td><?php echo $r['total']; ?></td><td><?php echo $r['pending']; ?></td>
        <td><?php echo $r['review']; ?></td><td><?php echo $r['approved']; ?></td><td><?php echo $r['rejected']; ?></td></tr>
  <?php } ?>
  </tbody>
</table></div>

<h5 class="mt-4">Scholarship Availability <small class="text-muted">(all dates)</small></h5>
<div class="table-responsive"><table class="table table-striped table-sm align-middle">
  <thead><tr><th>Scholarship</th><th>Total slots</th><th>Approved</th><th>Remaining</th><th>Deadline</th><th>Applications</th></tr></thead>
  <tbody>
  <?php foreach ($availability as $r) { $left = $r['slots'] - $r['approved']; ?>
    <tr><td><?php echo h($r['name']); ?></td><td><?php echo $r['slots']; ?></td><td><?php echo $r['approved']; ?></td>
        <td><?php echo $left; ?></td><td><?php echo h($r['deadline']); ?></td>
        <td><?php echo ($r['deadline'] >= date('Y-m-d') && $left > 0) ? 'Open' : 'Closed / Full'; ?></td></tr>
  <?php } ?>
  </tbody>
</table></div>

<h5 class="mt-4">GPA Statistics</h5>
<div class="table-responsive"><table class="table table-striped table-sm align-middle">
  <thead><tr><th>Group</th><th>Count</th><th>Average</th><th>Highest</th><th>Lowest</th></tr></thead>
  <tbody>
  <?php foreach ($gpaStats as $label => $g) { ?>
    <tr><td><?php echo h($label); ?></td><td><?php echo $g['n']; ?></td>
        <td><?php echo $g['n'] > 0 ? number_format($g['a'], 2) : '-'; ?></td>
        <td><?php echo $g['n'] > 0 ? number_format($g['mx'], 2) : '-'; ?></td>
        <td><?php echo $g['n'] > 0 ? number_format($g['mn'], 2) : '-'; ?></td></tr>
  <?php } ?>
  </tbody>
</table></div>

<?php } else { ?>

<div class="table-responsive"><table class="table table-striped table-sm align-middle">
  <thead><tr>
    <th><?php echo sortLink('date', 'Date', $sort, $dir); ?></th>
    <th><?php echo sortLink('student', 'Student', $sort, $dir); ?></th>
    <th>Program</th>
    <th><?php echo sortLink('scholarship', 'Scholarship', $sort, $dir); ?></th>
    <th><?php echo sortLink('gpa', 'GPA', $sort, $dir); ?></th>
    <th><?php echo sortLink('status', 'Status', $sort, $dir); ?></th>
    <th>Remarks</th>
  </tr></thead>
  <tbody>
  <?php foreach ($detail as $r) { ?>
    <tr><td><?php echo h($r['application_date']); ?></td>
        <td><?php echo h($r['student_name']); ?> <small class="text-muted">(<?php echo h($r['student_id']); ?>)</small></td>
        <td><?php echo h($r['program_name']); ?></td><td><?php echo h($r['scholarship_name']); ?></td>
        <td><?php echo h($r['gpa']); ?></td><td><?php echo badge($r['status_name']); ?></td>
        <td><?php echo h($r['remarks']); ?></td></tr>
  <?php }
  if (count($detail) == 0) echo '<tr><td colspan="7" class="text-center">No records match the filters.</td></tr>'; ?>
  </tbody>
</table></div>
<p class="text-muted"><?php echo count($detail); ?> record(s)</p>

<?php } ?>
<?php include 'footer.php'; ?>
