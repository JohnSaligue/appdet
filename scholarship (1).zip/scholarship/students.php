<?php
include 'config.php';
requireRole('admin');

// Delete (with confirmation in the browser)
if (isset($_POST['delete_id'])) {
    try {
        run("DELETE FROM students WHERE student_id=?", 's', array($_POST['delete_id']));
        flash('success', 'Student deleted.');
    } catch (mysqli_sql_exception $e) {
        flash('danger', 'Cannot delete this student because they have applications.');
    }
    redirect('students.php');
}

// Search / filter / sort
$q = trim($_GET['q'] ?? '');
$program = $_GET['program'] ?? '';
$year = $_GET['year'] ?? '';
$where = array('1=1'); $types = ''; $params = array();
if ($q != '') { $where[] = '(s.student_id LIKE ? OR s.name LIKE ?)'; $types .= 'ss'; $params[] = "%$q%"; $params[] = "%$q%"; }
if ($program != '') { $where[] = 's.program_id=?'; $types .= 'i'; $params[] = (int)$program; }
if ($year != '') { $where[] = 's.year_level=?'; $types .= 'i'; $params[] = (int)$year; }
list($sort, $dir, $col) = getSort(array('student_id' => 's.student_id', 'name' => 's.name',
    'program' => 'p.program_name', 'year' => 's.year_level', 'gpa' => 's.gpa'), 'name');

$rows = fetchAll("SELECT s.*, p.program_name FROM students s
                  JOIN programs p ON s.program_id=p.program_id
                  WHERE " . implode(' AND ', $where) . " ORDER BY $col $dir", $types, $params);
$programs = fetchAll("SELECT * FROM programs ORDER BY program_name");

$pageTitle = 'Students';
include 'header.php';
?>
<div class="page-head"><h1 class="page-title">Students</h1>
  <a href="student_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Add student</a></div>
<form method="get" class="filter-bar row g-2 mb-3 no-print">
  <div class="col-md-4"><input type="text" name="q" class="form-control" placeholder="Search ID or name" value="<?php echo h($q); ?>"></div>
  <div class="col-md-3">
    <select name="program" class="form-select">
      <option value="">All programs</option>
      <?php foreach ($programs as $p) { ?>
        <option value="<?php echo $p['program_id']; ?>" <?php if ($program == $p['program_id']) echo 'selected'; ?>><?php echo h($p['program_name']); ?></option>
      <?php } ?>
    </select>
  </div>
  <div class="col-md-2">
    <select name="year" class="form-select">
      <option value="">All years</option>
      <?php for ($i = 1; $i <= 4; $i++) { ?><option value="<?php echo $i; ?>" <?php if ($year == $i) echo 'selected'; ?>>Year <?php echo $i; ?></option><?php } ?>
    </select>
  </div>
  <div class="col-md-3">
    <button class="btn btn-primary">Search</button>
    <a href="students.php" class="btn btn-outline-secondary">Reset</a>
  </div>
</form>

<div class="table-responsive">
<table class="table table-striped table-hover align-middle">
  <thead><tr>
    <th><?php echo sortLink('student_id', 'Student ID', $sort, $dir); ?></th>
    <th><?php echo sortLink('name', 'Name', $sort, $dir); ?></th>
    <th><?php echo sortLink('program', 'Program', $sort, $dir); ?></th>
    <th><?php echo sortLink('year', 'Year', $sort, $dir); ?></th>
    <th><?php echo sortLink('gpa', 'GPA', $sort, $dir); ?></th>
    <th>Contact</th><th>Actions</th>
  </tr></thead>
  <tbody>
  <?php foreach ($rows as $r) { ?>
    <tr>
      <td><?php echo h($r['student_id']); ?></td>
      <td><?php echo h($r['name']); ?></td>
      <td><?php echo h($r['program_name']); ?></td>
      <td><?php echo h($r['year_level']); ?></td>
      <td><?php echo h($r['gpa']); ?></td>
      <td><?php echo h($r['contact']); ?></td>
      <td class="text-nowrap">
        <a class="btn btn-sm btn-outline-primary" href="student_form.php?id=<?php echo urlencode($r['student_id']); ?>"><i class="bi bi-pencil-square"></i> Edit</a>
        <form method="post" class="d-inline" onsubmit="return confirm('Delete this student?');">
          <input type="hidden" name="delete_id" value="<?php echo h($r['student_id']); ?>">
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i> Delete</button>
        </form>
      </td>
    </tr>
  <?php }
  if (count($rows) == 0) echo '<tr><td colspan="7" class="text-center">No students found.</td></tr>'; ?>
  </tbody>
</table>
</div>
<p class="text-muted"><?php echo count($rows); ?> record(s)</p>
<?php include 'footer.php'; ?>
