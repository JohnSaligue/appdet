<?php
include 'config.php';
if (isset($_SESSION['user_id'])) redirect('index.php');

$programs = fetchAll("SELECT * FROM programs ORDER BY program_name");
$errors = array();
$d = array('student_id' => '', 'name' => '', 'program_id' => '', 'year_level' => '1',
           'gpa' => '', 'contact' => '', 'username' => '');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($d as $k => $v) $d[$k] = trim($_POST[$k] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    // required fields
    foreach (array('student_id' => 'Student ID', 'name' => 'Name', 'program_id' => 'Program',
                   'gpa' => 'GPA', 'contact' => 'Contact information', 'username' => 'Username') as $k => $label) {
        if ($d[$k] == '') $errors[] = "$label is required.";
    }
    if ($password == '') $errors[] = 'Password is required.';

    // data types and formats
    if ($d['student_id'] != '' && !preg_match('/^[A-Za-z0-9-]{3,20}$/', $d['student_id']))
        $errors[] = 'Student ID may only contain letters, numbers and dashes (3-20 characters).';
    if ($d['gpa'] != '' && (!is_numeric($d['gpa']) || $d['gpa'] < 0 || $d['gpa'] > 4))
        $errors[] = 'GPA must be a number from 0.00 to 4.00.';
    if (!in_array($d['year_level'], array('1', '2', '3', '4'))) $errors[] = 'Year level must be 1 to 4.';
    if ($d['program_id'] != '' && fetchOne("SELECT program_id FROM programs WHERE program_id=?", 'i', array((int)$d['program_id'])) == null)
        $errors[] = 'Please choose a valid program.';
    if ($d['username'] != '' && !preg_match('/^[A-Za-z0-9_]{4,50}$/', $d['username']))
        $errors[] = 'Username must be 4-50 characters (letters, numbers, underscore).';
    if ($password != '' && strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password != $confirm) $errors[] = 'Passwords do not match.';

    // duplicate checking
    if (count($errors) == 0) {
        if (fetchOne("SELECT student_id FROM students WHERE student_id=?", 's', array($d['student_id'])) != null)
            $errors[] = 'That Student ID is already registered.';
        if (fetchOne("SELECT user_id FROM users WHERE username=?", 's', array($d['username'])) != null)
            $errors[] = 'That username is already taken.';
    }

    if (count($errors) == 0) {
        mysqli_begin_transaction($conn);
        try {
            run("INSERT INTO students (student_id, name, program_id, year_level, gpa, contact) VALUES (?,?,?,?,?,?)",
                'ssiids', array($d['student_id'], $d['name'], (int)$d['program_id'], (int)$d['year_level'], (float)$d['gpa'], $d['contact']));
            run("INSERT INTO users (username, password_hash, role, student_id) VALUES (?,?, 'student', ?)",
                'sss', array($d['username'], password_hash($password, PASSWORD_DEFAULT), $d['student_id']));
            mysqli_commit($conn);
            flash('success', 'Enrollment successful! You can now login.');
            redirect('login.php');
        } catch (mysqli_sql_exception $e) {
            mysqli_rollback($conn);
            $errors[] = 'Could not save your registration. Please try again.';
        }
    }
}
$pageTitle = 'Enroll';
include 'header.php';
?>
<div class="auth-split wide">
  <div class="auth-side">
    <i class="bi bi-person-plus-fill big-icon"></i>
    <h2>Start your enrollment</h2>
    <p>It takes about a minute. Once you are in, you can apply for any open scholarship.</p>
    <ul>
      <li><i class="bi bi-1-circle"></i> Fill in your student details</li>
      <li><i class="bi bi-2-circle"></i> Choose a username and password</li>
      <li><i class="bi bi-3-circle"></i> Log in and apply</li>
    </ul>
  </div>
  <div class="auth-form">
    <h3>Create your account</h3>
    <?php if (count($errors) > 0) { ?>
      <div class="alert alert-danger"><ul class="mb-0 ps-3"><?php foreach ($errors as $e) echo '<li>' . h($e) . '</li>'; ?></ul></div>
    <?php } ?>
    <form method="post" class="row g-3">
      <div class="col-12"><div class="form-section">About you</div></div>
      <div class="col-md-5">
        <label class="form-label">Student ID *</label>
        <input type="text" name="student_id" class="form-control" placeholder="2024-0009" value="<?php echo h($d['student_id']); ?>">
      </div>
      <div class="col-md-7">
        <label class="form-label">Full name *</label>
        <input type="text" name="name" class="form-control" value="<?php echo h($d['name']); ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Program *</label>
        <select name="program_id" class="form-select">
          <option value="">Choose your program</option>
          <?php foreach ($programs as $p) { ?>
            <option value="<?php echo $p['program_id']; ?>" <?php if ($d['program_id'] == $p['program_id']) echo 'selected'; ?>><?php echo h($p['program_name']); ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-6 col-md-3">
        <label class="form-label">Year *</label>
        <select name="year_level" class="form-select">
          <?php for ($i = 1; $i <= 4; $i++) { ?><option <?php if ($d['year_level'] == $i) echo 'selected'; ?>><?php echo $i; ?></option><?php } ?>
        </select>
      </div>
      <div class="col-6 col-md-3">
        <label class="form-label">GPA *</label>
        <input type="number" step="0.01" min="0" max="4" name="gpa" class="form-control" placeholder="0.00 - 4.00" value="<?php echo h($d['gpa']); ?>">
      </div>
      <div class="col-12">
        <label class="form-label">Email or phone *</label>
        <input type="text" name="contact" class="form-control" value="<?php echo h($d['contact']); ?>">
      </div>
      <div class="col-12"><div class="form-section">Your login</div></div>
      <div class="col-md-4">
        <label class="form-label">Username *</label>
        <input type="text" name="username" class="form-control" value="<?php echo h($d['username']); ?>">
      </div>
      <div class="col-md-4">
        <label class="form-label">Password *</label>
        <input type="password" name="password" class="form-control" placeholder="6+ characters">
      </div>
      <div class="col-md-4">
        <label class="form-label">Confirm *</label>
        <input type="password" name="confirm" class="form-control">
      </div>
      <div class="col-12">
        <button class="btn btn-primary btn-lg w-100">Create my account</button>
      </div>
    </form>
    <p class="text-center mt-3 mb-0">Already enrolled? <a href="login.php">Log in</a></p>
  </div>
</div>
<?php include 'footer.php'; ?>
