<?php
include 'config.php';
requireRole('admin');
$errors = array();
$editId = (int)($_GET['edit'] ?? 0);
$name = ''; $contact = '';

if (isset($_POST['delete_id'])) {
    try {
        run("DELETE FROM providers WHERE provider_id=?", 'i', array((int)$_POST['delete_id']));
        flash('success', 'Provider deleted.');
    } catch (mysqli_sql_exception $e) {
        flash('danger', 'Cannot delete this provider because it has scholarships.');
    }
    redirect('providers.php');
}

if (isset($_POST['save'])) {
    $editId = (int)$_POST['provider_id'];
    $name = trim($_POST['provider_name']);
    $contact = trim($_POST['contact_info']);
    if ($name == '') $errors[] = 'Provider name is required.';
    elseif (strlen($name) > 100) $errors[] = 'Provider name is too long (max 100 characters).';
    elseif (fetchOne("SELECT provider_id FROM providers WHERE provider_name=? AND provider_id<>?", 'si', array($name, $editId)) != null)
        $errors[] = 'That provider already exists.';
    if (strlen($contact) > 100) $errors[] = 'Contact info is too long (max 100 characters).';

    if (count($errors) == 0) {
        if ($editId > 0) run("UPDATE providers SET provider_name=?, contact_info=? WHERE provider_id=?", 'ssi', array($name, $contact, $editId));
        else run("INSERT INTO providers (provider_name, contact_info) VALUES (?, ?)", 'ss', array($name, $contact));
        flash('success', 'Provider saved.');
        redirect('providers.php');
    }
} elseif ($editId > 0) {
    $row = fetchOne("SELECT * FROM providers WHERE provider_id=?", 'i', array($editId));
    if ($row != null) { $name = $row['provider_name']; $contact = $row['contact_info']; } else $editId = 0;
}

$rows = fetchAll("SELECT p.*, (SELECT COUNT(*) FROM scholarships s WHERE s.provider_id=p.provider_id) AS total
                  FROM providers p ORDER BY p.provider_name");
$pageTitle = 'Providers';
include 'header.php';
?>
<h1 class="page-title">Scholarship Providers</h1>
<?php foreach ($errors as $e) echo '<div class="alert alert-danger">' . h($e) . '</div>'; ?>
<form method="post" class="filter-bar row g-2 mb-4">
  <input type="hidden" name="provider_id" value="<?php echo $editId; ?>">
  <div class="col-md-4"><input type="text" name="provider_name" class="form-control" placeholder="Provider name *" value="<?php echo h($name); ?>"></div>
  <div class="col-md-4"><input type="text" name="contact_info" class="form-control" placeholder="Contact info" value="<?php echo h($contact); ?>"></div>
  <div class="col-md-4">
    <button name="save" class="btn btn-primary"><?php echo $editId > 0 ? 'Update' : 'Add'; ?> Provider</button>
    <?php if ($editId > 0) echo '<a href="providers.php" class="btn btn-outline-secondary">Cancel</a>'; ?>
  </div>
</form>
<div class="table-responsive"><table class="table table-striped align-middle">
  <thead><tr><th>Provider</th><th>Contact</th><th>Scholarships</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r) { ?>
    <tr><td><?php echo h($r['provider_name']); ?></td><td><?php echo h($r['contact_info']); ?></td><td><?php echo $r['total']; ?></td>
      <td class="text-nowrap">
        <a class="btn btn-sm btn-outline-primary" href="providers.php?edit=<?php echo $r['provider_id']; ?>"><i class="bi bi-pencil-square"></i> Edit</a>
        <form method="post" class="d-inline" onsubmit="return confirm('Delete this provider?');">
          <input type="hidden" name="delete_id" value="<?php echo $r['provider_id']; ?>">
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i> Delete</button>
        </form>
      </td></tr>
  <?php } ?>
  </tbody>
</table></div>
<?php include 'footer.php'; ?>
