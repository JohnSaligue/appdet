<?php
include 'config.php';
requireRole('any');

if (isset($_POST['delete_id']) && isAdmin()) {
    try {
        run("DELETE FROM scholarships WHERE scholarship_id=?", 'i', array((int)$_POST['delete_id']));
        flash('success', 'Scholarship deleted.');
    } catch (mysqli_sql_exception $e) {
        flash('danger', 'Cannot delete this scholarship because it has applications.');
    }
    redirect('scholarships.php');
}

// Search / filter / sort
$q = trim($_GET['q'] ?? '');
$provider = $_GET['provider'] ?? '';
$open = $_GET['open'] ?? '';
$where = array('1=1'); $types = ''; $params = array();
if ($q != '') { $where[] = 'sc.name LIKE ?'; $types .= 's'; $params[] = "%$q%"; }
if ($provider != '') { $where[] = 'sc.provider_id=?'; $types .= 'i'; $params[] = (int)$provider; }
if ($open == 'open') $where[] = 'sc.deadline >= CURDATE()';
if ($open == 'closed') $where[] = 'sc.deadline < CURDATE()';
list($sort, $dir, $col) = getSort(array('name' => 'sc.name', 'provider' => 'pr.provider_name',
    'min_gpa' => 'sc.min_gpa', 'slots' => 'sc.slots', 'deadline' => 'sc.deadline'), 'deadline');

$rows = fetchAll("SELECT sc.*, pr.provider_name,
                  (SELECT COUNT(*) FROM applications a WHERE a.scholarship_id=sc.scholarship_id AND a.status_id=3) AS approved_count
                  FROM scholarships sc JOIN providers pr ON sc.provider_id=pr.provider_id
                  WHERE " . implode(' AND ', $where) . " ORDER BY $col $dir", $types, $params);
$providers = fetchAll("SELECT * FROM providers ORDER BY provider_name");

$applied = array();       // scholarships this student already applied for
if (!isAdmin()) {
    foreach (fetchAll("SELECT scholarship_id FROM applications WHERE student_id=?", 's', array($_SESSION['student_id'])) as $a)
        $applied[] = $a['scholarship_id'];
}

$pageTitle = 'Scholarships';
include 'header.php';
?>
<div class="page-head">
  <h1 class="page-title"><?php echo isAdmin() ? 'Scholarships' : 'Find scholarships'; ?></h1>
  <?php if (isAdmin()) echo '<a href="scholarship_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> New scholarship</a>'; ?>
</div>
<form method="get" class="filter-bar row g-2 mb-3 no-print">
  <div class="col-md-4"><input type="text" name="q" class="form-control" placeholder="Search scholarship name" value="<?php echo h($q); ?>"></div>
  <div class="col-md-3">
    <select name="provider" class="form-select">
      <option value="">All providers</option>
      <?php foreach ($providers as $p) { ?>
        <option value="<?php echo $p['provider_id']; ?>" <?php if ($provider == $p['provider_id']) echo 'selected'; ?>><?php echo h($p['provider_name']); ?></option>
      <?php } ?>
    </select>
  </div>
  <div class="col-md-2">
    <select name="open" class="form-select">
      <option value="">Open and closed</option>
      <option value="open" <?php if ($open == 'open') echo 'selected'; ?>>Open only</option>
      <option value="closed" <?php if ($open == 'closed') echo 'selected'; ?>>Closed only</option>
    </select>
  </div>
  <div class="col-md-3">
    <button class="btn btn-primary"><i class="bi bi-search"></i> Search</button>
    <a href="scholarships.php" class="btn btn-outline-secondary">Reset</a>
  </div>
</form>

<?php if (!isAdmin()) { ?>
<div class="sch-grid">
  <?php foreach ($rows as $r) {
      $isOpen = ($r['deadline'] >= date('Y-m-d'));
      if (in_array($r['scholarship_id'], $applied)) $action = '<span class="btn btn-outline-secondary w-100 disabled"><i class="bi bi-check2"></i> Already applied</span>';
      elseif ($isOpen) $action = '<a class="btn btn-primary w-100" href="apply.php?id=' . $r['scholarship_id'] . '">Apply now <i class="bi bi-arrow-right"></i></a>';
      else $action = '<span class="btn btn-outline-secondary w-100 disabled">Closed</span>';
      echo scholarCard($r, $action);
  } ?>
</div>
<?php if (count($rows) == 0) echo '<p class="text-muted">No scholarships match your search.</p>'; ?>

<?php } else { ?>
<div class="table-responsive">
<table class="table table-hover align-middle">
  <thead><tr>
    <th><?php echo sortLink('name', 'Scholarship', $sort, $dir); ?></th>
    <th><?php echo sortLink('provider', 'Provider', $sort, $dir); ?></th>
    <th><?php echo sortLink('min_gpa', 'Min GPA', $sort, $dir); ?></th>
    <th>Requirements</th>
    <th><?php echo sortLink('slots', 'Slots left', $sort, $dir); ?></th>
    <th><?php echo sortLink('deadline', 'Deadline', $sort, $dir); ?></th>
    <th></th>
  </tr></thead>
  <tbody>
  <?php foreach ($rows as $r) {
      $left = $r['slots'] - $r['approved_count'];
      $isOpen = ($r['deadline'] >= date('Y-m-d')); ?>
    <tr>
      <td><b><?php echo h($r['name']); ?></b></td>
      <td><?php echo h($r['provider_name']); ?></td>
      <td><?php echo h($r['min_gpa']); ?></td>
      <td class="small"><?php echo h($r['requirements']); ?></td>
      <td><?php echo $left; ?> of <?php echo $r['slots']; ?></td>
      <td><?php echo h($r['deadline']); ?>
          <?php echo $isOpen ? '<span class="status-pill pill-approved">Open</span>' : '<span class="status-pill pill-closed">Closed</span>'; ?></td>
      <td class="text-nowrap text-end">
        <a class="btn btn-sm btn-outline-primary" href="scholarship_form.php?id=<?php echo $r['scholarship_id']; ?>"><i class="bi bi-pencil-square"></i> Edit</a>
        <form method="post" class="d-inline" onsubmit="return confirm('Delete this scholarship?');">
          <input type="hidden" name="delete_id" value="<?php echo $r['scholarship_id']; ?>">
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i> Delete</button>
        </form>
      </td>
    </tr>
  <?php }
  if (count($rows) == 0) echo '<tr><td colspan="7" class="text-center text-muted">No scholarships found.</td></tr>'; ?>
  </tbody>
</table>
</div>
<?php } ?>
<p class="text-muted"><?php echo count($rows); ?> record(s)</p>
<?php include 'footer.php'; ?>
