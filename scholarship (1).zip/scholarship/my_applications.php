<?php
include 'config.php';
requireRole('student');
$sid = $_SESSION['student_id'];

// A student may cancel an application only while it is still Pending
if (isset($_POST['cancel_id'])) {
    $n = run("DELETE FROM applications WHERE application_id=? AND student_id=? AND status_id=1", 'is', array((int)$_POST['cancel_id'], $sid));
    flash($n > 0 ? 'success' : 'danger', $n > 0 ? 'Application cancelled.' : 'Only pending applications can be cancelled.');
    redirect('my_applications.php');
}

$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';
$where = array('a.student_id=?'); $types = 's'; $params = array($sid);
if ($q != '') { $where[] = 'sc.name LIKE ?'; $types .= 's'; $params[] = "%$q%"; }
if ($status != '') { $where[] = 'a.status_id=?'; $types .= 'i'; $params[] = (int)$status; }
list($sort, $dir, $col) = getSort(array('date' => 'a.application_date', 'scholarship' => 'sc.name', 'status' => 'a.status_id'), 'date');
if (!isset($_GET['sort'])) $dir = 'DESC';

$rows = fetchAll("SELECT a.*, sc.name AS scholarship_name, st.status_name
                  FROM applications a
                  JOIN scholarships sc ON a.scholarship_id=sc.scholarship_id
                  JOIN statuses st ON a.status_id=st.status_id
                  WHERE " . implode(' AND ', $where) . " ORDER BY $col $dir", $types, $params);
$statuses = fetchAll("SELECT * FROM statuses ORDER BY status_id");

$pageTitle = 'My Applications';
include 'header.php';
?>
<h1 class="page-title">My Applications</h1>
<form method="get" class="filter-bar row g-2 mb-3">
  <div class="col-md-5"><input type="text" name="q" class="form-control" placeholder="Search scholarship" value="<?php echo h($q); ?>"></div>
  <div class="col-md-3">
    <select name="status" class="form-select">
      <option value="">All statuses</option>
      <?php foreach ($statuses as $s) { ?>
        <option value="<?php echo $s['status_id']; ?>" <?php if ($status == $s['status_id']) echo 'selected'; ?>><?php echo h($s['status_name']); ?></option>
      <?php } ?>
    </select>
  </div>
  <div class="col-md-4">
    <button class="btn btn-primary">Search</button>
    <a href="my_applications.php" class="btn btn-outline-secondary">Reset</a>
    <a href="scholarships.php" class="btn btn-warning">Browse</a>
  </div>
</form>
<div class="table-responsive"><table class="table table-striped align-middle">
  <thead><tr>
    <th><?php echo sortLink('date', 'Date applied', $sort, $dir); ?></th>
    <th><?php echo sortLink('scholarship', 'Scholarship', $sort, $dir); ?></th>
    <th>GPA</th>
    <th><?php echo sortLink('status', 'Status', $sort, $dir); ?></th>
    <th>Evaluation remarks</th><th></th>
  </tr></thead>
  <tbody>
  <?php foreach ($rows as $r) { ?>
    <tr>
      <td><?php echo h($r['application_date']); ?></td>
      <td><?php echo h($r['scholarship_name']); ?></td>
      <td><?php echo h($r['gpa']); ?></td>
      <td><?php echo badge($r['status_name']); ?></td>
      <td><?php echo h($r['remarks']); ?></td>
      <td>
        <?php if ($r['status_id'] == ST_PENDING) { ?>
          <form method="post" onsubmit="return confirm('Cancel this application?');">
            <input type="hidden" name="cancel_id" value="<?php echo $r['application_id']; ?>">
            <button class="btn btn-sm btn-outline-danger">Cancel</button>
          </form>
        <?php } ?>
      </td>
    </tr>
  <?php }
  if (count($rows) == 0) echo '<tr><td colspan="6" class="text-center">No applications found.</td></tr>'; ?>
  </tbody>
</table></div>
<?php include 'footer.php'; ?>
